(function($){

	  $(window).load(function() {
    $('.flexslider').flexslider({
      animation: "slide",
      // contolNav: true
    });
  });


}) (jQuery);
